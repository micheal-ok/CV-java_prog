
package mikelcv;

public class MikelCv {

    public static void main(String[] args) {
   String name = "OKEDOKUN MICHAEL OPEYEMI";
        String address = "27, Broadway Estate, Ilogbo Ota, Ogun State";
        String phone = "+2349048432157";
        String email = "okedokunmicheal019@gmail.com";

        
       String objective = "Motivated software developer with 3 years of experience in Java and web technologies seeking a challenging position to leverage my skills and contribute to innovative projects."; 
        
       
        String education = "Bachelor of Science in Computer Science\n" +
                            "Oyo State College Of Agriculture and Technlogy \n" +
                            "Graduated: May 2022";
        
        

        // Experience
        String experience = "Software Developer Intern\n" +
                             "Tech Innovations Inc.\n" +
                             "Software Developer at Helsotek Solutions Inc. (2019 - Present)\\n- Developed and maintained web applications using Java and Spring Framework.\n" +
                             "Collaborated with cross-functional teams to design and implement new features.\n" +
                             "Gained hands-on experience with front-end technologies and version control systems.\n" +
                             "Managed and maintained version control using Git and GitHub.";

        String skills = "HTML, CSS, JavaScript.\n" +
                        "Java, Spring Framework.\n" +
                        "Website Designing, Wordpress, Godaddy.\n" +
                        "Problem-solving and analytical skills.";

        String hobbies = "Singing"; 
        
        
        String reference = "Mr Sikiru Kilani\n"
                + "+2348061527690"; 
        

        System.out.println("CURRICULUM VITAE\n");
        System.out.println("Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Phone: " + phone);
        System.out.println("Email: " + email);
        System.out.println("\nEducation:");
        System.out.println(education);
        System.out.println("\nExperience:");
        System.out.println(experience);
        System.out.println("\nSkills:");
        System.out.println(skills);
        System.out.println("\nHobbies:");
        System.out.println(hobbies);
        System.out.println("\nReference:");
        System.out.println(reference);
    }
}